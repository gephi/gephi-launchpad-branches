Hungarian algorithm for the assignment problem.
-------------------------------------------------------
Clean version 0.11
Educational version 0.11

Source code for the hungarian algorithm.

These can be run from a command window using

"java <filename>"
(for running the class file)

or
"javac <filename.java>"
(for compiling and running).

but of course you would be much better off to open the source
files in Eclipse or another IDE and study the code or change
the input arrays to the algorithm.

The HungarianAlgorithm.java is the clean file. The comments are
scarce. This is only intended as a method to use in your own programs
if you need it.

The HungarianAlgorithmEdu.java is the commented file whose purpose
is to explain the internal operation of the algorithm. It is great
to help you understand what is going on. Make sure you also read
the comments inside the code.

Hope you will find them useful,
Good luck!

Konstantine





